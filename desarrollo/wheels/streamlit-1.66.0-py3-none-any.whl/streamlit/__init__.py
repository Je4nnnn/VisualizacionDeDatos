# Copyright (c) Streamlit Inc. (2018-2022) Snowflake Inc. (2022-2026)
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

# isort: skip_file
# ruff: noqa: E402, A001

"""Streamlit.

How to use Streamlit in 3 seconds:

    1. Write an app
    >>> import streamlit as st
    >>> st.write(anything_you_want)

    2. Run your app
    $ streamlit run my_script.py

    3. Use your app
    A new tab will open on your browser. That's your Streamlit app!

    4. Modify your code, save it, and watch changes live on your browser.

Take a look at the other commands in this module to find out what else
Streamlit can do:

    >>> dir(streamlit)

Or try running our "Hello World":

    $ streamlit hello

For more detailed info, see https://docs.streamlit.io.
"""

# IMPORTANT: Prefix with an underscore anything that the user shouldn't see.

import os as _os

# Set Matplotlib backend to avoid a crash.
# The default Matplotlib backend crashes Python on OSX when run on a thread
# that's not the main thread, so here we set a safer backend as a fix.
# This fix is OS-independent. We didn't see a good reason to make this
# Mac-only. Consistency within Streamlit seemed more important.
# IMPORTANT: This needs to run on top of all imports before any other
# import of matplotlib could happen.
_os.environ["MPLBACKEND"] = "Agg"


# Must be at the top, to avoid circular dependency.
from streamlit import logger as _logger
from streamlit import config as _config
from streamlit.version import STREAMLIT_VERSION_STRING as _STREAMLIT_VERSION_STRING
from typing import Final as _Final, cast as _cast

# Give the package a version.
__version__ = _STREAMLIT_VERSION_STRING

# DeltaGenerator methods:
# We initialize them here so that it is clear where they are instantiated.
# Further, it helps us to break circular imports because the DeltaGenerator
# imports the different elements but some elements also require DeltaGenerator
# functions such as the dg_stack. Now, elements that require DeltaGenerator functions
# can import the singleton module.
from streamlit.delta_generator_singletons import (
    DeltaGeneratorSingleton as _DeltaGeneratorSingleton,
)
from streamlit.delta_generator import DeltaGenerator as _DeltaGenerator
from streamlit.elements.lib.mutable_status_container import (
    StatusContainer as _StatusContainer,
)
from streamlit.elements.lib.dialog import Dialog as _Dialog
from streamlit.elements.lib.mutable_expander_container import (
    ExpanderContainer as _ExpanderContainer,
)
from streamlit.elements.lib.mutable_tab_container import TabContainer as _TabContainer
from streamlit.elements.lib.mutable_popover_container import (
    PopoverContainer as _PopoverContainer,
)
from streamlit.elements.lib.skeleton_placeholder import (
    SkeletonPlaceholder as _SkeletonPlaceholder,
)

# instantiate the DeltaGeneratorSingleton
_dg_singleton = _DeltaGeneratorSingleton(
    delta_generator_cls=_DeltaGenerator,
    status_container_cls=_StatusContainer,
    dialog_container_cls=_Dialog,
    expander_container_cls=_ExpanderContainer,
    tab_container_cls=_TabContainer,
    popover_container_cls=_PopoverContainer,
    skeleton_placeholder_cls=_SkeletonPlaceholder,
)
_main: _DeltaGenerator = _dg_singleton._main_dg
sidebar: _DeltaGenerator = _dg_singleton._sidebar_dg
_event: _DeltaGenerator = _dg_singleton._event_dg

from streamlit.elements.bottom import BottomContainerProxy as _BottomContainerProxy

# The internal _bottom_dg is used by both the public `bottom` and the deprecated `_bottom`
_bottom_dg_internal: _DeltaGenerator = _dg_singleton._bottom_dg
# Use cast to DeltaGenerator for static analysis so type checkers see all DeltaGenerator methods.
# At runtime, bottom is a BottomContainerProxy that validates the execution context.
bottom: _DeltaGenerator = _cast(
    "_DeltaGenerator", _BottomContainerProxy(_bottom_dg_internal)
)

# Deprecated: use `st.bottom` instead
from streamlit.deprecation_util import deprecate_obj_name as _deprecate_obj_name

_bottom: _DeltaGenerator = _deprecate_obj_name(
    _bottom_dg_internal, "_bottom", "bottom", "2026-07-01"
)


from streamlit.elements.dialog_decorator import dialog_decorator as _dialog_decorator
from streamlit.runtime.caching import (
    cache_resource as _cache_resource,
    cache_data as _cache_data,
)
from streamlit.runtime.connection_factory import (
    connection_factory as _connection,
)
from streamlit.runtime.fragment import fragment as _fragment
from streamlit.runtime.metrics_util import gather_metrics as _gather_metrics
from streamlit.runtime.secrets import secrets_singleton as _secrets_singleton
from streamlit.runtime.context import ContextProxy as _ContextProxy
from streamlit.runtime.state import (
    SessionStateProxy as _SessionStateProxy,
    QueryParamsProxy as _QueryParamsProxy,
)
from streamlit.user_info import (
    UserInfoProxy as _UserInfoProxy,
    login as _login,
    logout as _logout,
)

import streamlit.column_config as _column_config
import streamlit.typing as _typing

# Modules that the user should have access to. These are imported with the "as" syntax
# and the same name; note that renaming the import with "as" does not make it an
# explicit export. In this case, you should import it with an underscore to make clear
# that it is internal and then assign it to a variable with the new intended name.
# You can check the export behavior by running 'mypy --strict example_app.py', which
# disables implicit_reexport, where you use the respective command in the example_app.py
# Streamlit app.

from streamlit.commands.echo import echo as echo
from streamlit.commands.logo import logo as logo
from streamlit.navigation.page import Page as Page
from streamlit.commands.navigation import navigation as _navigation

# Declare the command so type checkers resolve `st.navigation` to this callable,
# not the `streamlit.navigation` package of the same name.
navigation: _Final = _navigation

from streamlit.commands.page_config import set_page_config as set_page_config
from streamlit.commands.execution_control import (
    stop as stop,
    rerun as rerun,
    switch_page as switch_page,
)


def _update_logger() -> None:
    _logger.set_log_level(_config.get_option("logger.level").upper())
    _logger.update_formatter()
    _logger.init_uvicorn_logs()


# Make this file only depend on config option in an asynchronous manner. This
# avoids a race condition when another file (such as a test file) tries to pass
# in an alternative config.
_config.on_config_parsed(_update_logger, True)

secrets = _secrets_singleton

altair_chart = _main.altair_chart
area_chart = _main.area_chart
audio = _main.audio
audio_input = _main.audio_input
badge = _main.badge
balloons = _main.balloons
bar_chart = _main.bar_chart
_bidi_component = _main._bidi_component
button = _main.button
caption = _main.caption
camera_input = _main.camera_input
chat_message = _main.chat_message
chat_input = _main.chat_input
checkbox = _main.checkbox
code = _main.code
columns = _main.columns
tabs = _main.tabs
container = _main.container
dataframe = _main.dataframe
data_editor = _main.data_editor
date_input = _main.date_input
datetime_input = _main.datetime_input
divider = _main.divider
download_button = _main.download_button
echarts_chart = _main.echarts_chart
expander = _main.expander
feedback = _main.feedback
pydeck_chart = _main.pydeck_chart
empty = _main.empty
error = _main.error
exception = _main.exception
file_uploader = _main.file_uploader
form = _main.form
form_submit_button = _main.form_submit_button
graphviz_chart = _main.graphviz_chart
header = _main.header
help = _main.help
html = _main.html
iframe = _main.iframe
image = _main.image
info = _main.info
json = _main.json
latex = _main.latex
line_chart = _main.line_chart
link_button = _main.link_button
map = _main.map
markdown = _main.markdown
menu_button = _main.menu_button
mermaid_chart = _main.mermaid_chart
metric = _main.metric
multiselect = _main.multiselect
number_input = _main.number_input
page_link = _main.page_link
pagination = _main.pagination
pdf = _main.pdf
pills = _main.pills
plotly_chart = _main.plotly_chart
popover = _main.popover
progress = _main.progress
pyplot = _main.pyplot
radio = _main.radio
scatter_chart = _main.scatter_chart
selectbox = _main.selectbox
select_slider = _main.select_slider
segmented_control = _main.segmented_control
skeleton = _main.skeleton
slider = _main.slider
snow = _main.snow
space = _main.space
spinner = _main.spinner
subheader = _main.subheader
success = _main.success
table = _main.table
text = _main.text
text_area = _main.text_area
text_input = _main.text_input
toggle = _main.toggle
time_input = _main.time_input
title = _main.title
vega_lite_chart = _main.vega_lite_chart
video = _main.video
warning = _main.warning
write = _main.write
write_stream = _main.write_stream
color_picker = _main.color_picker
status = _main.status

# Events - Note: these methods cannot be called directly on sidebar
# (ex: st.sidebar.toast)
toast = _event.toast

# Config
# We add the metrics tracking here, since importing
# gather_metrics in config causes a circular dependency
get_option = _gather_metrics("get_option", _config.get_option)
set_option = _gather_metrics("set_option", _config.set_user_option)

# Session State
session_state = _SessionStateProxy()

query_params = _QueryParamsProxy()

context = _ContextProxy()

# Caching
cache_data = _cache_data
cache_resource = _cache_resource

# Namespaces
column_config = _column_config
typing = _typing

# Connection
connection = _connection

# Fragment and dialog
dialog = _dialog_decorator
fragment = _fragment


# Auth
login = _login
logout = _logout

# User
user = _UserInfoProxy()

# Starlette integration
from streamlit.starlette import App as App

# make it possible to call streamlit.components.v1.html etc. by importing it here
# import in the very end to avoid partially-initialized module import errors, because
# streamlit.components.v1 also uses some streamlit imports
# Explicitly re-export the namespace because type checkers don't infer it from
# the submodule import side effects below.
from streamlit import components as components
import streamlit.components.v1  # noqa: F401
import streamlit.components.v2  # noqa: F401

# Runtime-only module ``__getattr__``. Hide it from type checkers so unknown
# ``st.*`` names stay type errors. mypy only honors the unaliased
# ``TYPE_CHECKING`` name here; an alias made unknown names type-check as
# valid. Deleting it afterward keeps it off the public ``st`` surface.
from types import ModuleType as _ModuleType
from typing import TYPE_CHECKING


class _MissingStreamlitAttributeMessage:
    """Lazy ``AttributeError`` argument for a missing top-level ``st.*`` name.

    ``hasattr``, ``getattr`` with a default, and ``from streamlit import``
    catch this error without formatting it. The suggestion text is built
    only when ``str()`` runs, so those lookups do not import
    ``streamlit.command_suggestions`` or ``difflib``.
    """

    def __init__(self, name: str, module: _ModuleType) -> None:
        self._name = name
        self._module = module

    def __str__(self) -> str:
        try:
            # Import the submodule directly so a failed load hits the fallback
            # below. ``from streamlit import`` looks the name up first and
            # re-enters ``__getattr__``.
            import streamlit.command_suggestions as command_suggestions  # noqa: PLR0402

            return command_suggestions.missing_streamlit_attribute_message(
                self._name, self._module
            )
        except Exception:  # pragma: no cover - defensive
            return f"module 'streamlit' has no attribute '{self._name}'"


if not TYPE_CHECKING:

    def __getattr__(name: str) -> object:
        import sys

        module = sys.modules[__name__]
        # Telemetry records AttributeError.name and .obj as
        # AttributeError:<attribute> instead of parsing the message.
        raise AttributeError(
            _MissingStreamlitAttributeMessage(name, module),
            name=name,
            obj=module,
        )


# Drop TYPE_CHECKING so it is not a public ``st`` name.
del TYPE_CHECKING
